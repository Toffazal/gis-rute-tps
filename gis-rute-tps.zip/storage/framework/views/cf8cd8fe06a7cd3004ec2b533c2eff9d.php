<?php $__env->startSection('content'); ?>
    <style>
        #dashboard-map {
            height: 450px;
            border-radius: 10px;
            border: 2px solid #dee2e6;
            z-index: 1;
        }

        .status-badge {
            font-size: 0.75rem;
            padding: 4px 10px;
            border-radius: 20px;
        }

        .destination-card {
            border-left: 4px solid #0d6efd;
            transition: all 0.2s;
        }

        .destination-card.active {
            border-left-color: #198754;
            background-color: #f0fff4;
        }

        .destination-card.selesai {
            border-left-color: #6c757d;
            opacity: 0.7;
        }

        .destination-card.dilewati {
            border-left-color: #dc3545;
            opacity: 0.7;
        }

        .tujuan-list-item {
            padding: 10px 15px;
            border-bottom: 1px solid #eee;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .tujuan-list-item:last-child {
            border-bottom: none;
        }

        .urutan-badge {
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 0.8rem;
            font-weight: bold;
            color: #fff;
            flex-shrink: 0;
        }
    </style>

    
    <div class="row">
        <div class="col-12">
            <div class="white-box p-3">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2">
                    <div>
                        <h5 class="mb-1 fw-bold">Selamat datang, <?php echo e($user->name); ?>!</h5>
                        <p class="text-muted mb-0">
                            <i class="fas fa-calendar me-1"></i> <?php echo e(\Carbon\Carbon::today()->translatedFormat('l, d F Y')); ?>

                            &mdash; Hari: <strong><?php echo e($hariIni); ?></strong>
                        </p>
                    </div>
                    <div>
                        <?php if($ruteHarian): ?>
                            <?php if($ruteHarian->status === 'belum_mulai'): ?>
                                <span class="badge bg-warning text-dark status-badge me-2">
                                    <i class="fas fa-clock me-1"></i> Belum Dimulai
                                </span>
                                <form action="<?php echo e(route('sopir.rute.mulai', $ruteHarian->id)); ?>" method="POST"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success btn-sm"
                                        onclick="return confirm('Mulai rute pengangkutan hari ini?')">
                                        <i class="fas fa-play me-1"></i> Mulai Rute
                                    </button>
                                </form>
                            <?php elseif($ruteHarian->status === 'berlangsung'): ?>
                                <span class="badge bg-primary status-badge me-2">
                                    <i class="fas fa-truck me-1"></i> Sedang Berlangsung
                                </span>
                                <form action="<?php echo e(route('sopir.rute.selesaiRute', $ruteHarian->id)); ?>" method="POST"
                                    class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-outline-danger btn-sm"
                                        onclick="return confirm('Yakin ingin mengakhiri rute hari ini? Semua tujuan yang belum dikunjungi akan ditandai sebagai tidak dikunjungi.')">
                                        <i class="fas fa-flag-checkered me-1"></i> Selesaikan Rute
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="badge bg-success status-badge">
                                    <i class="fas fa-check-circle me-1"></i> Rute Selesai
                                </span>
                            <?php endif; ?>
                        <?php else: ?>
                            <span class="badge bg-secondary status-badge">
                                <i class="fas fa-info-circle me-1"></i> Tidak ada jadwal hari ini
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php if($ruteHarian && $ruteHarian->ruteTujuan->count() > 0): ?>
        
        <?php if($tujuanAktif && $ruteHarian->status === 'berlangsung'): ?>
            <div class="row">
                <div class="col-12">
                    <div class="white-box p-3 destination-card active">
                        <div class="d-flex justify-content-between align-items-start flex-wrap gap-2">
                            <div>
                                <h6 class="fw-bold text-success mb-1">
                                    <i class="fas fa-map-pin me-1"></i>
                                    Tujuan Berikutnya — #<?php echo e($tujuanAktif->urutan); ?>

                                </h6>
                                <h5 class="fw-bold mb-1">
                                    <?php if($tujuanAktif->tipe === 'tpa'): ?>
                                        <i class="fas fa-industry me-1 text-danger"></i> TPA
                                    <?php else: ?>
                                        <i class="fas fa-map-marker-alt me-1 text-primary"></i>
                                        <?php echo e($tujuanAktif->tps->nama ?? 'TPS'); ?>

                                    <?php endif; ?>
                                </h5>
                                <?php if($tujuanAktif->tps): ?>
                                    <p class="text-muted mb-1">
                                        <i class="fas fa-road me-1"></i>
                                        <?php echo e($tujuanAktif->tps->alamat ?? '-'); ?>

                                    </p>
                                <?php endif; ?>
                                <small class="text-muted">
                                    <i class="fas fa-ruler me-1"></i>
                                    Jarak: <?php echo e(number_format($tujuanAktif->jarak_dari_sebelumnya_meter / 1000, 1)); ?> km
                                </small>
                            </div>
                            <div class="d-flex flex-wrap gap-2">
                                
                                <?php
                                    if ($tujuanAktif->tipe === 'tpa') {
                                        $navLat = $tpaCoord[0];
                                        $navLng = $tpaCoord[1];
                                    } else {
                                        $navLat = $tujuanAktif->tps->latitude ?? 0;
                                        $navLng = $tujuanAktif->tps->longitude ?? 0;
                                    }
                                ?>
                                <a href="https://www.google.com/maps/dir/?api=1&destination=<?php echo e($navLat); ?>,<?php echo e($navLng); ?>&travelmode=driving"
                                    target="_blank" class="btn btn-primary btn-sm">
                                    <i class="fas fa-directions me-1"></i> Navigasi
                                </a>

                                
                                <?php if(!$tujuanAktif->waktu_tiba): ?>
                                    <form action="<?php echo e(route('sopir.rute.tiba', $tujuanAktif->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-info btn-sm text-white"
                                            onclick="return confirm('Tandai sudah tiba di lokasi ini?')">
                                            <i class="fas fa-map-pin me-1"></i> Tiba
                                        </button>
                                    </form>
                                <?php endif; ?>

                                
                                <?php if($tujuanAktif->waktu_tiba): ?>
                                    <form action="<?php echo e(route('sopir.rute.selesai', $tujuanAktif->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success btn-sm"
                                            onclick="return confirm('Tandai selesai pengangkutan di lokasi ini?')">
                                            <i class="fas fa-check me-1"></i> Selesai
                                        </button>
                                    </form>
                                <?php endif; ?>

                                
                                <button type="button" class="btn btn-outline-danger btn-sm" data-bs-toggle="modal"
                                    data-bs-target="#skipModal">
                                    <i class="fas fa-forward me-1"></i> Skip
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        
        <div class="row">
            <div class="col-12">
                <div class="white-box p-3">
                    <h6 class="fw-bold mb-3"><i class="fas fa-map me-2 text-primary"></i>Peta Rute Pengangkutan</h6>
                    <div id="dashboard-map"></div>
                </div>
            </div>
        </div>

        
        <div class="row">
            <div class="col-12">
                <div class="white-box p-0">
                    <div class="p-3 border-bottom">
                        <h6 class="fw-bold mb-0"><i class="fas fa-list-ol me-2 text-primary"></i>Urutan Tujuan Kunjungan
                        </h6>
                    </div>
                    <?php $__currentLoopData = $ruteHarian->ruteTujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tujuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="tujuan-list-item">
                            <?php
                                $bgColor = match ($tujuan->status) {
                                    'selesai' => '#198754',
                                    'aktif' => '#0d6efd',
                                    'dilewati' => '#dc3545',
                                    'tidak_dikunjungi' => '#6c757d',
                                    default => '#adb5bd',
                                };
                            ?>
                            <div class="urutan-badge" style="background-color: <?php echo e($bgColor); ?>">
                                <?php echo e($tujuan->urutan); ?>

                            </div>
                            <div class="flex-grow-1">
                                <strong>
                                    <?php if($tujuan->tipe === 'tpa'): ?>
                                        <i class="fas fa-industry text-danger me-1"></i> TPA
                                    <?php else: ?>
                                        <?php echo e($tujuan->tps->nama ?? 'TPS'); ?>

                                    <?php endif; ?>
                                </strong>
                                <?php if($tujuan->tps): ?>
                                    <br><small class="text-muted"><?php echo e($tujuan->tps->alamat ?? ''); ?></small>
                                <?php endif; ?>
                            </div>
                            <div class="text-end d-flex align-items-center gap-2">
                                <div>
                                    <small class="text-muted d-block mb-1">
                                        <?php echo e(number_format($tujuan->jarak_dari_sebelumnya_meter / 1000, 1)); ?> km
                                    </small>
                                    <?php
                                        $statusLabel = match ($tujuan->status) {
                                            'selesai' => '<span class="badge bg-success">Selesai</span>',
                                            'aktif' => '<span class="badge bg-primary">Aktif</span>',
                                            'dilewati' => '<span class="badge bg-danger">Dilewati</span>',
                                            'tidak_dikunjungi'
                                                => '<span class="badge bg-secondary">Tidak Dikunjungi</span>',
                                            default => '<span class="badge bg-light text-dark">Menunggu</span>',
                                        };
                                    ?>
                                    <?php echo $statusLabel; ?>

                                </div>
                                <?php if($tujuan->status === 'menunggu' && $tujuan->tipe === 'tps' && $ruteHarian->status === 'berlangsung'): ?>
                                    <form action="<?php echo e(route('sopir.rute.mulaiManual', $tujuan->id)); ?>" method="POST"
                                        class="ms-1">
                                        <?php echo csrf_field(); ?>
                                        <button type="submit" class="btn btn-success btn-sm py-1 px-2 text-white"
                                            style="font-size: 0.75rem;"
                                            onclick="return confirm('Kunjungi TPS ini sekarang? Urutan rute sisa lainnya akan dihitung ulang secara otomatis.')">
                                            <i class="fas fa-play me-1"></i> Mulai
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="p-3 border-top bg-light">
                        <div class="d-flex justify-content-between">
                            <strong>Total Estimasi Jarak:</strong>
                            <strong class="text-primary">
                                <?php echo e(number_format(($ruteHarian->total_jarak_meter ?? 0) / 1000, 1)); ?> km</strong>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <?php if($tujuanAktif && $ruteHarian->status === 'berlangsung'): ?>
            <div class="modal fade" id="skipModal" tabindex="-1" aria-labelledby="skipModalLabel" aria-hidden="true"
                data-bs-backdrop="static" data-bs-keyboard="false">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <form action="<?php echo e(route('sopir.rute.skip', $tujuanAktif->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header">
                                <h5 class="modal-title" id="skipModalLabel">Lewati Tujuan</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"
                                    aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <p>Anda akan melewati:
                                    <strong><?php echo e($tujuanAktif->tps->nama ?? 'TPA'); ?></strong>
                                </p>
                                <div class="form-group mb-3">
                                    <label class="form-label fw-bold">Opsi Pengabaian <span
                                            class="text-danger">*</span></label>
                                    <div class="form-check p-0">
                                        <div class="mb-2">
                                            <input class="form-check-input ms-0 me-2" type="radio" name="status_skip"
                                                id="status_skip_dilewati" value="dilewati" checked required>
                                            <label class="form-check-label fw-bold" for="status_skip_dilewati">
                                                Dilewati (Kunjungi Nanti)
                                            </label>
                                            <span class="d-block text-muted ms-4" style="font-size: 0.8rem;">
                                                TPS dilewati sementara, akan dikunjungi di akhir urutan sebelum TPA dengan
                                                rute yang dioptimalkan kembali.
                                            </span>
                                        </div>
                                        <div>
                                            <input class="form-check-input ms-0 me-2" type="radio" name="status_skip"
                                                id="status_skip_tidak_dikunjungi" value="tidak_dikunjungi" required>
                                            <label class="form-check-label fw-bold" for="status_skip_tidak_dikunjungi">
                                                Tidak Dikunjungi (Batal)
                                            </label>
                                            <span class="d-block text-muted ms-4" style="font-size: 0.8rem;">
                                                TPS dibatalkan sepenuhnya untuk pengangkutan hari ini.
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="alasan" class="form-label fw-bold">Alasan <span
                                            class="text-danger">*</span></label>
                                    <textarea name="alasan" id="alasan" class="form-control" rows="3" required
                                        placeholder="Jelaskan alasan melewati tujuan ini..."></textarea>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary text-white"
                                    data-bs-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-danger">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="row">
            <div class="col-12">
                <div class="white-box text-center py-5">
                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">Tidak ada jadwal pengangkutan untuk hari ini</h5>
                    <p class="text-muted">Silakan cek halaman <a href="<?php echo e(route('sopir.jadwal.index')); ?>">Jadwal</a>
                        untuk melihat jadwal lengkap Anda.</p>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if($ruteHarian && $ruteHarian->ruteTujuan->count() > 0): ?>
                const kantorCoord = [<?php echo e($kantorCoord[0]); ?>, <?php echo e($kantorCoord[1]); ?>];
                const tpaCoord = [<?php echo e($tpaCoord[0]); ?>, <?php echo e($tpaCoord[1]); ?>];

                const map = L.map('dashboard-map').setView(kantorCoord, 13);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    attribution: '© OpenStreetMap'
                }).addTo(map);

                // Custom icons
                const kantorIcon = L.divIcon({
                    html: '<i class="fas fa-building" style="color: #198754; font-size: 22px; text-shadow: 0 1px 3px rgba(0,0,0,0.4);"></i>',
                    className: 'custom-div-icon',
                    iconSize: [22, 22],
                    iconAnchor: [11, 22],
                    popupAnchor: [0, -22]
                });

                const tpaIcon = L.divIcon({
                    html: '<i class="fas fa-industry" style="color: #dc3545; font-size: 22px; text-shadow: 0 1px 3px rgba(0,0,0,0.4);"></i>',
                    className: 'custom-div-icon',
                    iconSize: [22, 22],
                    iconAnchor: [11, 22],
                    popupAnchor: [0, -22]
                });

                // Kantor marker
                L.marker(kantorCoord, {
                    icon: kantorIcon
                }).addTo(map).bindPopup(
                    '<strong><i class="fas fa-building text-success me-1"></i> Kantor (Start)</strong>');

                // TPA marker
                L.marker(tpaCoord, {
                    icon: tpaIcon
                }).addTo(map).bindPopup(
                    '<strong><i class="fas fa-industry text-danger me-1"></i> TPA (Finish)</strong>');

                // Route points for polyline
                const routePoints = [kantorCoord];

                // TPS markers
                <?php $__currentLoopData = $ruteHarian->ruteTujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tujuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($tujuan->tipe === 'tps' && $tujuan->tps): ?>
                        (function() {
                            const coord = [<?php echo e($tujuan->tps->latitude); ?>, <?php echo e($tujuan->tps->longitude); ?>];
                            const status = '<?php echo e($tujuan->status); ?>';

                            let color = '#6c757d';
                            if (status === 'aktif') color = '#0d6efd';
                            else if (status === 'selesai') color = '#198754';
                            else if (status === 'dilewati') color = '#dc3545';
                            else color = '#fd7e14'; // menunggu

                            const tpsIcon = L.divIcon({
                                html: '<div style="background:' + color +
                                    ';color:#fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:bold;box-shadow:0 1px 3px rgba(0,0,0,0.4);"><?php echo e($tujuan->urutan); ?></div>',
                                className: 'custom-div-icon',
                                iconSize: [24, 24],
                                iconAnchor: [12, 24],
                                popupAnchor: [0, -24]
                            });

                            L.marker(coord, {
                                    icon: tpsIcon
                                }).addTo(map)
                                .bindPopup(
                                    '<strong>#<?php echo e($tujuan->urutan); ?> - <?php echo e($tujuan->tps->nama); ?></strong><br>' +
                                    '<small><?php echo e($tujuan->tps->alamat ?? ''); ?></small><br>' +
                                    '<span class="badge" style="background:' + color +
                                    '"><?php echo e(ucfirst($tujuan->status)); ?></span>'
                                );

                            routePoints.push(coord);
                        })();
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                // Add TPA as last point
                routePoints.push(tpaCoord);

                // Draw polyline
                L.polyline(routePoints, {
                    color: '#0d6efd',
                    weight: 3,
                    opacity: 0.7,
                    dashArray: '10, 6'
                }).addTo(map);

                // Fit bounds
                const bounds = L.latLngBounds(routePoints);
                map.fitBounds(bounds, {
                    padding: [30, 30]
                });
            <?php endif; ?>
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('sopir.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\KERJAAN PRIBADI\gis-rute-tps\resources\views/sopir/dashboard.blade.php ENDPATH**/ ?>