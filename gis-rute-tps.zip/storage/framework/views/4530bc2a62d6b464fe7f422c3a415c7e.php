<?php $__env->startSection('content'); ?>
    <style>
        #riwayat-map {
            height: 400px;
            border-radius: 10px;
            border: 2px solid #dee2e6;
            z-index: 1;
        }

        .timeline {
            position: relative;
            padding-left: 30px;
        }

        .timeline::before {
            content: '';
            position: absolute;
            left: 12px;
            top: 0;
            bottom: 0;
            width: 2px;
            background: #dee2e6;
        }

        .timeline-item {
            position: relative;
            margin-bottom: 15px;
            padding: 10px 15px;
            background: #f8f9fa;
            border-radius: 8px;
            border-left: 3px solid #0d6efd;
        }

        .timeline-item::before {
            content: '';
            position: absolute;
            left: -24px;
            top: 15px;
            width: 10px;
            height: 10px;
            border-radius: 50%;
            background: #0d6efd;
            border: 2px solid #fff;
            box-shadow: 0 0 0 2px #0d6efd;
        }

        .timeline-item.aksi-selesai {
            border-left-color: #198754;
        }

        .timeline-item.aksi-selesai::before {
            background: #198754;
            box-shadow: 0 0 0 2px #198754;
        }

        .timeline-item.aksi-skip {
            border-left-color: #dc3545;
        }

        .timeline-item.aksi-skip::before {
            background: #dc3545;
            box-shadow: 0 0 0 2px #dc3545;
        }

        .timeline-item.aksi-tiba {
            border-left-color: #0dcaf0;
        }

        .timeline-item.aksi-tiba::before {
            background: #0dcaf0;
            box-shadow: 0 0 0 2px #0dcaf0;
        }
    </style>

    <div class="mb-2">
        <a href="<?php echo e(route('sopir.riwayat.index')); ?>" class="btn btn-secondary btn-sm text-white">
            <i class="fas fa-arrow-left me-1"></i> Kembali
        </a>
    </div>

    
    <div class="white-box">
        <div class="row g-3">
            <div class="col-md-3 col-6">
                <small class="text-muted">Tanggal</small>
                <p class="fw-bold mb-0"><?php echo e($ruteHarian->tanggal->translatedFormat('l, d M Y')); ?></p>
            </div>
            <div class="col-md-3 col-6">
                <small class="text-muted">Angkutan</small>
                <p class="fw-bold mb-0">
                    <?php echo e($ruteHarian->angkutan->nama ?? '-'); ?>

                    <small class="text-muted">(<?php echo e($ruteHarian->angkutan->nomor ?? '-'); ?>)</small>
                </p>
            </div>
            <div class="col-md-3 col-6">
                <small class="text-muted">Total Jarak</small>
                <p class="fw-bold mb-0 text-primary">
                    <?php echo e(number_format(($ruteHarian->total_jarak_meter ?? 0) / 1000, 1)); ?> km
                </p>
            </div>
            <div class="col-md-3 col-6">
                <small class="text-muted">Durasi</small>
                <p class="fw-bold mb-0">
                    <?php if($ruteHarian->total_durasi_detik): ?>
                        <?php
                            $durasi = abs($ruteHarian->total_durasi_detik);
                            $jam = floor($durasi / 3600);
                            $menit = floor(($durasi % 3600) / 60);
                        ?>
                        <?php echo e($jam > 0 ? $jam . ' jam ' : ''); ?><?php echo e($menit); ?> menit
                    <?php else: ?>
                        -
                    <?php endif; ?>
                </p>
            </div>
        </div>
    </div>

    
    <div class="white-box">
        <h6 class="fw-bold mb-3"><i class="fas fa-map me-2 text-primary"></i>Peta Rute</h6>
        <div id="riwayat-map"></div>
    </div>

    <div class="row">
        
        <div class="col-md-6 col-12">
            <div class="white-box">
                <h6 class="fw-bold mb-3"><i class="fas fa-list-ol me-2 text-primary"></i>Daftar Tujuan</h6>
                <div class="table-responsive">
                    <table class="table table-sm table-hover mb-0">
                        <thead class="table-light">
                            <tr>
                                <th>#</th>
                                <th>Tujuan</th>
                                <th>Status</th>
                                <th>Jarak</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $ruteHarian->ruteTujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tujuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tujuan->urutan); ?></td>
                                    <td>
                                        <?php if($tujuan->tipe === 'tpa'): ?>
                                            <i class="fas fa-industry text-danger me-1"></i> TPA
                                        <?php else: ?>
                                            <i class="fas fa-map-marker-alt text-primary me-1"></i>
                                            <?php echo e($tujuan->tps->nama ?? 'TPS'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <?php
                                            $statusBadge = match ($tujuan->status) {
                                                'selesai' => 'bg-success',
                                                'dilewati' => 'bg-danger',
                                                'tidak_dikunjungi' => 'bg-secondary',
                                                default => 'bg-light text-dark',
                                            };
                                        ?>
                                        <span class="badge <?php echo e($statusBadge); ?>"><?php echo e(ucfirst($tujuan->status)); ?></span>
                                        <?php if($tujuan->alasan): ?>
                                            <br><small class="text-muted"><?php echo e($tujuan->alasan); ?></small>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e(number_format($tujuan->jarak_dari_sebelumnya_meter / 1000, 1)); ?> km</td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        
        <div class="col-md-6 col-12">
            <div class="white-box">
                <h6 class="fw-bold mb-3"><i class="fas fa-clock me-2 text-primary"></i>Timeline Aktivitas</h6>

                <?php if($ruteHarian->ruteLog->isEmpty()): ?>
                    <p class="text-muted text-center">Tidak ada log aktivitas.</p>
                <?php else: ?>
                    <div class="timeline">
                        <?php $__currentLoopData = $ruteHarian->ruteLog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $aksiClass = match ($log->aksi) {
                                    'selesai' => 'aksi-selesai',
                                    'skip' => 'aksi-skip',
                                    'tiba' => 'aksi-tiba',
                                    default => '',
                                };
                                $aksiLabel = match ($log->aksi) {
                                    'mulai_rute' => '<i class="fas fa-play-circle text-success me-1"></i> Mulai Rute',
                                    'tiba' => '<i class="fas fa-map-pin text-info me-1"></i> Tiba',
                                    'selesai' => '<i class="fas fa-check-circle text-success me-1"></i> Selesai',
                                    'skip' => '<i class="fas fa-forward text-danger me-1"></i> Dilewati',
                                    'tidak_dikunjungi' => '<i class="fas fa-times-circle text-secondary me-1"></i> Tidak Dikunjungi',
                                    default => ucfirst(str_replace('_', ' ', $log->aksi)),
                                };
                            ?>
                            <div class="timeline-item <?php echo e($aksiClass); ?>">
                                <div class="d-flex justify-content-between">
                                    <strong><?php echo $aksiLabel; ?></strong>
                                    <small class="text-muted"><?php echo e($log->created_at->format('H:i:s')); ?></small>
                                </div>
                                <?php if($log->ruteTujuan): ?>
                                    <small class="text-muted">
                                        <?php if($log->ruteTujuan->tipe === 'tpa'): ?>
                                            TPA
                                        <?php else: ?>
                                            <?php echo e($log->ruteTujuan->tps->nama ?? 'TPS'); ?>

                                        <?php endif; ?>
                                    </small>
                                <?php endif; ?>
                                <?php if($log->alasan): ?>
                                    <br><small class="text-danger">Alasan: <?php echo e($log->alasan); ?></small>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const kantorCoord = [<?php echo e($kantorCoord[0]); ?>, <?php echo e($kantorCoord[1]); ?>];
            const tpaCoord = [<?php echo e($tpaCoord[0]); ?>, <?php echo e($tpaCoord[1]); ?>];

            const map = L.map('riwayat-map').setView(kantorCoord, 13);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '© OpenStreetMap'
            }).addTo(map);

            const kantorIcon = L.divIcon({
                html: '<i class="fas fa-building" style="color: #198754; font-size: 22px; text-shadow: 0 1px 3px rgba(0,0,0,0.4);"></i>',
                className: 'custom-div-icon',
                iconSize: [22, 22],
                iconAnchor: [11, 22],
                popupAnchor: [0, -22]
            });

            const tpaIcon = L.divIcon({
                html: '<i class="fas fa-industry" style="color: #dc3545; font-size: 22px; text-shadow: 0 1px 3px rgba(0,0,0,0.4);"></i>',
                className: 'custom-div-icon',
                iconSize: [22, 22],
                iconAnchor: [11, 22],
                popupAnchor: [0, -22]
            });

            L.marker(kantorCoord, {
                icon: kantorIcon
            }).addTo(map).bindPopup('<strong><i class="fas fa-building text-success me-1"></i> Kantor (Start)</strong>');
            L.marker(tpaCoord, {
                icon: tpaIcon
            }).addTo(map).bindPopup('<strong><i class="fas fa-industry text-danger me-1"></i> TPA (Finish)</strong>');

            const routePoints = [kantorCoord];

            <?php $__currentLoopData = $ruteHarian->ruteTujuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tujuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($tujuan->tipe === 'tps' && $tujuan->tps): ?>
                    (function() {
                        const coord = [<?php echo e($tujuan->tps->latitude); ?>, <?php echo e($tujuan->tps->longitude); ?>];
                        const status = '<?php echo e($tujuan->status); ?>';
                        let color = status === 'selesai' ? '#198754' : (status === 'dilewati' ? '#dc3545' :
                            '#6c757d');

                        const icon = L.divIcon({
                            html: '<div style="background:' + color +
                                ';color:#fff;width:24px;height:24px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:bold;box-shadow:0 1px 3px rgba(0,0,0,0.4);"><?php echo e($tujuan->urutan); ?></div>',
                            className: 'custom-div-icon',
                            iconSize: [24, 24],
                            iconAnchor: [12, 24],
                            popupAnchor: [0, -24]
                        });

                        L.marker(coord, {
                            icon: icon
                        }).addTo(map).bindPopup(
                            '<strong>#<?php echo e($tujuan->urutan); ?> - <?php echo e($tujuan->tps->nama); ?></strong><br>' +
                            '<span class="badge" style="background:' + color +
                            '"><?php echo e(ucfirst($tujuan->status)); ?></span>'
                        );
                        routePoints.push(coord);
                    })();
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            routePoints.push(tpaCoord);

            L.polyline(routePoints, {
                color: '#0d6efd',
                weight: 3,
                opacity: 0.7,
                dashArray: '10, 6'
            }).addTo(map);

            const bounds = L.latLngBounds(routePoints);
            map.fitBounds(bounds, {
                padding: [30, 30]
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('sopir.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\KERJAAN PRIBADI\gis-rute-tps\resources\views/sopir/riwayat/show.blade.php ENDPATH**/ ?>