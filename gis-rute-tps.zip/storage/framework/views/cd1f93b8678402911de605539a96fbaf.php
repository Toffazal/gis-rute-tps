<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="white-box">
                <h3 class="box-title">Jadwal Pengangkutan Saya</h3>

                <?php $__currentLoopData = $hariList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hari): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $jadwalHari = $jadwalAll->get($hari, collect());
                    ?>
                    <div class="mb-4">
                        <h5 class="fw-bold text-primary">
                            <i class="fas fa-calendar-day me-2"></i><?php echo e($hari); ?>

                            <span class="badge bg-light text-dark ms-2"><?php echo e($jadwalHari->count()); ?> jadwal</span>
                        </h5>

                        <?php if($jadwalHari->isEmpty()): ?>
                            <p class="text-muted ms-4"><em>Tidak ada jadwal</em></p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover table-bordered mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th width="50">#</th>
                                            <th>TPS</th>
                                            <th>Angkutan</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $jadwalHari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $jadwal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($idx + 1); ?></td>
                                                <td>
                                                    <i class="fas fa-map-marker-alt text-primary me-1"></i>
                                                    <?php echo e($jadwal->tps->nama ?? '-'); ?>

                                                </td>
                                                <td>
                                                    <i class="fas fa-truck text-success me-1"></i>
                                                    <?php echo e($jadwal->angkutan->nama ?? '-'); ?>

                                                    <small class="text-muted">(<?php echo e($jadwal->angkutan->nomor ?? '-'); ?>)</small>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sopir.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\KERJAAN PRIBADI\gis-rute-tps\resources\views/sopir/jadwal/index.blade.php ENDPATH**/ ?>