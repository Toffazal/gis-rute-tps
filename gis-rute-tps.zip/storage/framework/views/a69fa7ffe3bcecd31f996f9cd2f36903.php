<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="white-box">
                <h3 class="box-title">Riwayat Pengangkutan</h3>

                <?php if($riwayat->isEmpty()): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-history fa-3x text-muted mb-3"></i>
                        <p class="text-muted">Belum ada riwayat pengangkutan.</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead class="table-light">
                                <tr>
                                    <th width="50">#</th>
                                    <th>Tanggal</th>
                                    <th>Angkutan</th>
                                    <th>Jumlah TPS</th>
                                    <th>Total Jarak</th>
                                    <th>Durasi</th>
                                    <th width="80">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $idx => $rute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($riwayat->firstItem() + $idx); ?></td>
                                        <td>
                                            <i class="fas fa-calendar me-1 text-primary"></i>
                                            <?php echo e($rute->tanggal->translatedFormat('l, d M Y')); ?>

                                        </td>
                                        <td>
                                            <i class="fas fa-truck me-1 text-success"></i>
                                            <?php echo e($rute->angkutan->nama ?? '-'); ?>

                                            <small class="text-muted">(<?php echo e($rute->angkutan->nomor ?? '-'); ?>)</small>
                                        </td>
                                        <td class="text-center">
                                            <?php echo e($rute->ruteTujuan->where('tipe', 'tps')->count()); ?>

                                        </td>
                                        <td>
                                            <?php echo e(number_format(($rute->total_jarak_meter ?? 0) / 1000, 1)); ?> km
                                        </td>
                                        <td>
                                            <?php if($rute->total_durasi_detik): ?>
                                                <?php
                                                    $durasi = abs($rute->total_durasi_detik);
                                                    $jam = floor($durasi / 3600);
                                                    $menit = floor(($durasi % 3600) / 60);
                                                ?>
                                                <?php echo e($jam > 0 ? $jam . ' jam ' : ''); ?><?php echo e($menit); ?> menit
                                            <?php else: ?>
                                                -
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center">
                                            <a href="<?php echo e(route('sopir.riwayat.show', $rute->id)); ?>"
                                                class="btn btn-sm btn-outline-primary" title="Detail">
                                                <i class="fas fa-eye"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="d-flex justify-content-center mt-3">
                        <?php echo e($riwayat->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sopir.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\KERJAAN PRIBADI\gis-rute-tps\resources\views/sopir/riwayat/index.blade.php ENDPATH**/ ?>