<?php
    $template = auth()->user()->role === 'sopir' ? 'sopir.template' : 'admin.template';
?>




<?php $__env->startSection('content'); ?>

    <div class="white-box">
        <h4 class="box-title"><?php echo e(__('Profile Information')); ?></h4>

        <div class="basic-form">
            <form method="POST" action="<?php echo e(route('profile.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('patch'); ?>

                <div class="form-group">
                    <label for="name"><?php echo e(__('Name')); ?></label>
                    <input type="text" id="name" name="name" class="form-control" placeholder="Name"
                        value="<?php echo e(old('name', $user->name)); ?>" required autocomplete="name">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="username"><?php echo e(__('Username')); ?></label>
                    <input type="text" id="username" name="username" class="form-control" placeholder="Username"
                        value="<?php echo e(old('username', $user->username)); ?>" required>
                    <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="email"><?php echo e(__('Email Address')); ?></label>
                    <input type="email" id="email" name="email" class="form-control" placeholder="Email"
                        value="<?php echo e(old('email', $user->email)); ?>" required autocomplete="username">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="text-danger small mt-1"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <?php if($user instanceof \Illuminate\Contracts\Auth\MustVerifyEmail && !$user->hasVerifiedEmail()): ?>
                        <div class="mt-2">
                            <p class="text-warning small mb-1">
                                <?php echo e(__('Your email address is unverified.')); ?>

                                <button type="submit" form="send-verification"
                                    class="btn btn-link btn-sm p-0 align-baseline">
                                    <?php echo e(__('Click here to re-send the verification email.')); ?>

                                </button>
                            </p>
                            <?php if(session('status') === 'verification-link-sent'): ?>
                                <p class="text-success small">
                                    <?php echo e(__('A new verification link has been sent to your email address.')); ?>

                                </p>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>

                    <?php if(session('status') === 'profile-updated'): ?>
                        <span class="text-success small ms-2"><?php echo e(__('Saved.')); ?></span>
                    <?php endif; ?>
                </div>
            </form>

            <form id="send-verification" method="post" action="<?php echo e(route('verification.send')); ?>" class="d-none">
                <?php echo csrf_field(); ?>
            </form>
        </div>
    </div>


    <div class="white-box">
        <h4 class="box-title"><?php echo e(__('Update Password')); ?></h4>

        <div class="basic-form">
            <form method="POST" action="<?php echo e(route('password.update')); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('put'); ?>

                <div class="row">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="current_password"><?php echo e(__('Current Password')); ?></label>
                            <input id="current_password" name="current_password" type="password" class="form-control"
                                autocomplete="current-password">
                            <button type="button"
                                class="btn btn-outline-secondary btn-sm toggle-password float-end position-relative"
                                style="top: -32px; right: 5px;" data-target="current_password">
                                👁
                            </button>
                            <?php if($errors->updatePassword->has('current_password')): ?>
                                <div class="text-danger small mt-1">
                                    <?php echo e($errors->updatePassword->first('current_password')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="password"><?php echo e(__('New Password')); ?></label>
                            <input id="password" name="password" type="password" class="form-control"
                                autocomplete="new-password">
                            <button type="button"
                                class="btn btn-outline-secondary btn-sm toggle-password float-end position-relative"
                                style="top: -32px; right: 5px;" data-target="password">
                                👁
                            </button>
                            <?php if($errors->updatePassword->has('password')): ?>
                                <div class="text-danger small mt-1">
                                    <?php echo e($errors->updatePassword->first('password')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="form-group">
                            <label for="password_confirmation"><?php echo e(__('Confirm Password')); ?></label>
                            <input id="password_confirmation" name="password_confirmation" type="password"
                                class="form-control" autocomplete="new-password">
                            <button type="button"
                                class="btn btn-outline-secondary btn-sm toggle-password float-end position-relative"
                                style="top: -32px; right: 5px;" data-target="password_confirmation">
                                👁
                            </button>
                            <?php if($errors->updatePassword->has('password_confirmation')): ?>
                                <div class="text-danger small mt-1">
                                    <?php echo e($errors->updatePassword->first('password_confirmation')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>







                <div class="form-group">
                    <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>

                    <?php if(session('status') === 'password-updated'): ?>
                        <span class="text-success small ms-2"><?php echo e(__('Password updated successfully.')); ?></span>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>


    
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.querySelectorAll('.toggle-password').forEach(button => {
                button.addEventListener('click', function() {
                    const targetId = this.dataset.target;
                    const input = document.getElementById(targetId);
                    if (input.type === 'password') {
                        input.type = 'text';
                        this.innerText = '🙈';
                    } else {
                        input.type = 'password';
                        this.innerText = '👁';
                    }
                });
            });
        </script>
    <?php $__env->stopPush(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make($template, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\KERJAAN PRIBADI\gis-rute-tps\resources\views/profile/edit.blade.php ENDPATH**/ ?>